/*#include <iostream>
int main()
{
int vowels=5;
switch(vowels){
    case 1:
    std::cout<<"a";
    break;
     case 2:
    std::cout<<"e";
    break;
     case 3:
    std::cout<<"i";
    break;
     case 4:
    std::cout<<"o";
    break;
     case 5:
    std::cout<<"u";
    break;
    case 6:
    std::cout<<"y, i guess";
    default:
    std::cout<<"there isn't any.";
    break;
}
return 0;
}*/
#include <iostream>
int main()
{
    int senses=5;
    switch(senses)
    {
    case 1:
    std::cout<<"sight";
    break;
    case 2:
    std::cout<<"hearing";
    break;
    case 3:
    std::cout<<"smell";
    break;
    case 4:
    std::cout<<"taste";
    break;
    case 5:
    std::cout<<"touch";
    break;
    default:
    std::cout<<"wrong";
    }
    return 0;
}