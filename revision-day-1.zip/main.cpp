#include <iostream>
#include <string>
int main()
{
/*std::string stringOne="concat";
std::string stringTwo="enation";
std::cout<<stringOne+stringTwo<<"\n";
std::cout<<stringOne.append(stringTwo);*/
/*std::string string="llejfnfkandkfenfkadkfnekfankdnfkefnkandkfenkndfkenakndfkneka";
std::cout<<string.length();*/
/*std::string stringOne="something";
std::string stringTwo="funny";
std::cout<<stringOne[5]<<"\n";
stringTwo[0]='b';
std::cout<<stringTwo;*/
/*std::string string;
std::cout<<"Type a sentence. ";
getline(std::cin, string);
std::cout<<string;*/
/*int x=12312;
int y=10;
if(x<y)
{
    std::cout<<"Hello World";
}
else{
    std::cout<<"Goodbye World";
}*/
/*int theTime=3;
if(theTime<8)
{
    std::cout<<"Good morning.";
}
else if(theTime>8 && theTime<16)
{
    std::cout<<"Good evening.";
}
else{
    std::cout<<"Good night.";
}*/
/*int theTime=901;
switch(theTime)
{
    case 900:
    std::cout<<"C++ Class or C# Class on the Weekends";
    break;
    case 1130:
    std::cout<<"Boomi Class";
    break;
    case 100:
    std::cout<<"Java Class or SQL on the Weekends";
    break;
    case 330:
    std::cout<<"Snowflake Class";
    case 500:
    std::cout<<"HTTL and CSS Class or C# on the Weekends";
    break;
    default:
    std::cout<<"In the middle of a class, or not in a class.";
    }*/
    /*int i=1;
    while(i<=7)
    {
        std::cout<<"Simon says hello. \n";
        i++;
    }
    return 0;*/
    /*int i=1;
    do{
        std::cout<<i<<"\n";
        i++;
    }
    while(i<=10);*/
    int i, j, r;
    
}