'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
x="annoying"
print(len(x))
glass_of_water="4";
print("I drank "+glass_of_water+" glasses of water.")
men_stepped_on_the_moon="12"
print( men_stepped_on_the_moon,"men stopped on the moon.")
sentence="nah my dad had a whole operation he is the man behind the coding classes bruh what"
print(sentence)
x=98
y=45.67
z="Python"
print(type(x))
print(type(y))
print(type(z))
x=y=z=100
print(x,y,z)
x="stromg"
y="basestring"
print(x+y)
x,y,z=5,4,3
print(x,y,z)
