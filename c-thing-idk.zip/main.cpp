#include <iostream>
void myFunction(){
    std::cout<<"mincrft"<<"\n";
}
void Function2(std::string firstName){
    std::cout<<firstName<<" Nguyen"<<"\n";
}
void Function3(std::string flowerName, std::string flowerColor)
{
    std::cout<<flowerName<<"="<<flowerColor<<"\n";
}
int main()
{
/*
struct{
    int myInt;
    std::string myString;
} myStructure;
myStructure.myInt=1;
myStructure.myString="500 beans";
std::cout<<myStructure.myInt<<" "<<myStructure.myString;*/
/*struct{
    std::string fruitName;
    std::string fruitColor;
} fruitOne, fruitTwo, fruitThree;
fruitOne.fruitName="apple";
fruitOne.fruitColor="red";
fruitTwo.fruitName="orange";
fruitTwo.fruitColor="orange";
fruitThree.fruitName="banana";
fruitThree.fruitColor="yellow";
std::cout<<fruitOne.fruitName<<"="<<fruitOne.fruitColor<<"\n"<<fruitTwo.fruitName<<"="<<fruitTwo.fruitColor<<"\n"<<fruitThree.fruitName<<"="<<fruitThree.fruitColor;*/
/*std::string extraordinary="extraordinary";
std::string *ptr=&extraordinary;
std::cout<<*ptr<<"\n";
*ptr="ordinary";
std::cout<<*ptr;*/
/*myFunction();
myFunction();
myFunction();myFunction();myFunction();
myFunction();
myFunction();myFunction();myFunction();myFunction();myFunction();myFunction();myFunction();myFunction();myFunction();

myFunction();
myFunction();myFunction();myFunction();myFunction();myFunction();myFunction();myFunction();myFunction();myFunction();
myFunction();
myFunction();myFunction();myFunction();myFunction();
myFunction();myFunction();
myFunction();
myFunction();*/
/*Function2("Raymond");
Function2("Brian");*/
Function3("rose", "red");
Function3("violets","blue");
}