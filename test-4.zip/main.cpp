#include <iostream>
int main()
{
    //Question 1
    
   /* int num=11;
    switch(num)
    {
        case 1:
        std::cout<<"one";
        break;
        case 2:
        std::cout<<"two";
        break;
        case 3:
        std::cout<<"three";
        break;
        case 4:
        std::cout<<"four";
        break;
        case 5:
        std::cout<<"five";
        break;
        case 6:
        std::cout<<"six";
        break;
        case 7:
        std::cout<<"seven";
        break;
        case 8:
        std::cout<<"eight";
        break;
        case 9:
        std::cout<<"nine";
        break;
        case 10:
        std::cout<<"ten";
        break;
        default:
        std::cout<<"Only numbers from 1-10.";
    }*/
    
    //Question 2
    
   /* int i=-1;
    while(i>=-10)
    {
        std::cout<<i<<"\n";
        i--;
    }
    return 0;*/
    //Question 3
    /*for(int num=1; num<=10; num++)
    {
        std::cout<<num<<"\n";
    }*/
    
    //Question 4
    
    /*for (int num=2; num<=40; num=num+2)
    {
        std::cout<<num<<"\n";
    }*/
    
    //Question 5
    /*int sum=0;
 for(int num=1; num<=10; num++)
 {
     std::cout<<num<<"\n";
     sum+=num;
 }
 std::cout<<sum;*/
 int i=12;
 switch(i)
{
    case 1:
    std::cout<<"1";
    break;
    case 2:
    std::cout<<"2";
    break;
    case 3:
    std::cout<<"3";
    break;
    case 5:
    std::cout<<"5";
    break;
    case 7:
    std::cout<<"7";
    break;
    case 11:
    std::cout<<"11";
    break;
    default:
    std::cout<<"Not prime or in between 1-11.";
}
return 0;
}