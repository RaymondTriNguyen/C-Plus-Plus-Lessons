/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <iostream>
int main()
{
    int age=18;
    if (age>=18)
    {
        std::cout<<"You are an adult.";
    }
    return 0;
}*/
/*#include <iostream>
int main()
{
    int dayOfWeek=1;
    if (dayOfWeek=1)
    {
        std::cout<<"It is a Monday.";
    }
        else if (dayOfWeek=2)
    {
        std::cout<<"It is a Tuesday";
    }
     else if (dayOfWeek=3)
    {
        std::cout<<"It is a Wednesday";
    }
     else if (dayOfWeek=4)
    {
        std::cout<<"It is a Thursday.";
    }
     else if (dayOfWeek=5)
    {
        std::cout<<"It is a Friday.";
    }
     else if (dayOfWeek=6)
    {
        std::cout<<"It is a Saturday.";
    }
     else if (dayOfWeek=7)
    {
        std::cout<<"It is a Sunday.";
    }
    else{
        std::cout<<"That isn't a day!";
    }
    return 0;
}*/
/*#include <iostream>
int main()
{
    int month=12;
    switch (month)
    {
        case 1:
        std::cout<<"January";
        break;
        case 2:
        std::cout<<"February";
        break;
        case 3:
        std::cout<<"March";
        break;
        case 4:
        std::cout<<"April";
        break;
        case 5:
        std::cout<<"May";
        break;
        case 6:
        std::cout<<"June";
        break;
        case 7:
        std::cout<<"July";
        break;
        case 8:
        std::cout<<"August";
        break;
        case 9:
        std::cout<<"September";
        break;
        case 10:
        std::cout<<"October";
        break;
        case 11:
        std::cout<<"November";
        break;
        case 12:
        std::cout<<"December";
        break;
    }
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    std::string monthOfYear;
    std::cout<<"What month is it?";
    std::cin>>monthOfYear;
    std::cout<<"The month is "<<monthOfYear<<".";
}*/
#include <iostream>
int main()
{
    int x=10231;
    int y=10000;
    std::cout<<"The max is "<<std::max(x,y)<<"\n";
    std::cout<<"The minimum is "<<std::min(x,y);
}
