#include <iostream>
#include <string>
int main()
{
    /*struct
    {
     int myNum;
     std::string bean;
    } myStructure;
//std::cout<<"Write a number. ";
//std::cin>>myStructure.myNum;
std::cout<<"Write a word. ";
getline(std::cin,myStructure.bean);
std::cout<<myStructure.myNum<<"\n"<<myStructure.bean;*/
/*struct
{
    double price;
    std::string name;
    std::string color;
}
fruit1, fruit2, fruit3;
fruit1.price=1;
fruit1.color="red";
fruit1.name="apple";
fruit2.price=1.5;
fruit2.color="orange";
fruit2.name="orange";
fruit3.price=2;
fruit3.color="yellow";
fruit3.name="banana";
std::cout<<fruit1.color<<", "<<fruit1.price<<", "<<fruit1.name<<"\n";
std::cout<<fruit2.color<<", "<<fruit2.price<<", "<<fruit2.name<<"\n";
std::cout<<fruit3.color<<", "<<fruit3.price<<", "<<fruit3.name<<"\n";*/
std::string food="spaghet";
std::string yum=food;
std::cout<<food<<"\n";
std::cout<<yum;
}