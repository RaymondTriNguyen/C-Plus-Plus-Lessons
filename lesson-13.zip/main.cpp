/*#include <iostream>
int main()
{
    int num, product=5;
    do {
        std::cout<<"Enter a number, enter ''1'' to end it. It is all going to be multiplied by 5."<<"\n";
        std::cin>>num;
        product*=num;
    }
    while(num!=1);
      std::cout<<"The product is "<<product<<".";
    return 0;
}*/
/*#include <iostream>
int main()
{
    double num, quotient=5;
    do {
        std::cout<<"Enter a number, enter ''1'' to end it. It is all going to be divided by 5."<<"\n";
        std::cin>>num;
        quotient/=num;
    }
    while(num!=1);
      std::cout<<"The quotient is "<<quotient<<".";
    return 0;
}*/
#include <iostream>
int main()
{
    int i=1;
    do {
        std::cout<<i<<"\n";
        i++;
    }
    while(i>0);
    return 0;
}
