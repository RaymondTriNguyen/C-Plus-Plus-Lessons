#include <iostream>
    int myFunction(int x)
    {
       if(x>0)
       {
           return x+myFunction(x-1);
       }
    }
    int main()
    {
  int result=myFunction(10);
  std::cout<<result;
  return 0;
    }