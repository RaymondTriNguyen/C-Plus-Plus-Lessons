#include <iostream>
#include <string>
int main()
{
int j, i, n;
std::cout<<"Input a number.";
std::cin>>n;
std::cout<<"The multiplication table from 1 to "<<n<<"."<<std::endl;
for (i=1;i<=100;i++)
{
    for (j=1;j<=n;j++)
    {
        if (j <= n-1)
        std::cout<<j<<"x"<<i<<"= "<<i*j<<"\t";
        else
        std::cout<<j<<"x"<<i<<"= "<<i*j<<"\t";
    }
    std::cout<<std::endl;
}
return 0;
}

