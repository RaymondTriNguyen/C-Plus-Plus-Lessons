#include <iostream>
int main()
{
std::string letters[2][2][2][2]{
    {
    {
    {"a","b"},
    {"c","d"}
},
{
    {"e","f"},
    {"g","h"}
}
},
 {
    {
    {"i","j"},
    {"k","l"}
},
{
    {"m","n"},
    {"o","p"}
}
 }
    
};
for(int i=0; i<2; i++)
for(int j=0; j<2; j++)
for(int k=0; k<2; k++)
for(int m=0; m<2; m++)
{{{{
    std::cout<<letters[i][j][k][m]<<"\n";
}}}}
}
