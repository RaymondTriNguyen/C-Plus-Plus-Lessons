#include <iostream>
#include <cmath>
int main()
{
    //Question 1
    /*std::string bean;
    std::cout<<"Write a sentence. ";
    getline(std::cin,bean);
    std::cout<<bean;*/
    //Question 2
    /*int x=10;
    int y=5;
    std::cout<<(x>y && y<x)<<"\n";
    std::cout<<(y>x || x>y);*/
    //Question 3
    /*std::string bean="Kind";
    bean[0]='W';
    std::cout<<bean;*/
    //Question 4
    //std::cout<<log(9)<<"\n"<<sqrt(84);
    //Question 5
    /*int x;
    std::cout<<"Enter positive numbers. \n";
    std::cin>>x;
if (x>0)
{
    std::cout<<x;
}
else{
    std::cout<<"It is skipped.";
}*/
//Question 6
/*int x=5;
int y=10;
if (x<y)
{
    std::cout<<"I am learning if-else conditional statements.";
}*/
//Question 7
/*int x=5;
int y=10;
if (x<y)
{
    std::cout<<"x is less than y.";
}*/
//Question 8
/*int x=0;
if(x=1)
{
    std::cout<<"true";
}
else if (x=0)
{
    std::cout<<"false";
}
else{
    std::cout<<"no";
}*/
//Question 9
/*int x=3;
switch(x)
{
    case 1:
    {
        std::cout<<"one";
        break;
    }
        case 2:
    {
        std::cout<<"two";
        break;
    }
        case 3:
    {
        std::cout<<"three";
        break;
    }
    default: {
        std::cout<<"has to be 1-3";
    }
}*/
//Question 10
/*int x=1;
while(x<=10)
{
    std::cout<<x<<"\n";
    x++;
}*/
//Question 11
/*int x;
int sum=1;
do
{
    std::cout<<"Input a number.";
    std::cin>>x;
    sum=x+sum;
}
while(x!=1);
std::cout<<sum;*/
//Quesion 12
/*for(int i=1;i<100;i=i+2)
{
    std::cout<<i<<"\n";
}*/
//Question 13
/*for(int i=1;i<=5;i++)
{
    std::cout<<"Assignment day \n";
}*/
//Question 14
/*int sum=0;
for(int i=1;i<=10;i++)
{
    std::cout<<i<<"\n";
    sum=sum+i;
}
std::cout<<sum;*/
//Question 15
/*for (int i=1;i<=64;i=i*2)
{
    std::cout<<i<<"\n";
}*/
//Question 16
/*int i, k, n;

    std::cout << "Please enter number of rows you want to see: \n";
    std::cin >> n;
    for (k = 1; k <= n; k++)
    {
        for (i = 1; i <= k; i++)
            std::cout << '+';
        std::cout << std::endl;
    }
    return 0;   */
    
}
