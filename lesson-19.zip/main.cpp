#include <iostream>
void homework()
{
    std::cout<<"I will do my homework. \n";
}
int main()
{
    for(int hw=1; hw<100; hw++)
    {
        homework();
    }
}