#include <iostream>
int main()
{
    for (int i=1; i<=2; ++i)
    {
        std::cout<<"Outer: "<<i<<"\n";
        for (int j=1; j<=2;++j)
        {
            std::cout<<"Inner: "<<j<<"\n";
            for (int k=1; k<=2;++k)
        {
            std::cout<<"Innerer: "<<k<<"\n";
            for (int l=1;l<=2;++l)
            {
                std::cout<<"Innererer: "<<l<<"\n";
                for (int m=1; m<=2;++m)
        {
            std::cout<<"Innerererer: "<<m<<"\n";
            for (int n=1; n<=2;++n)
        {
            std::cout<<"Innererererer: "<<n<<"\n";
            for (int o=1; o<=2;++o)
        {
            std::cout<<"Innerererererer: "<<o<<"\n";
            for (int p=1; p<=2;++p)
        {
            std::cout<<"Innererererererer: "<<p<<"\n";
            for (int q=1; q<=2;++q)
        {
            std::cout<<"Innerererererererer: "<<q<<"\n";
            for (int r=1; r<=2;++r)
        {
            std::cout<<"Innererererererererer: "<<r<<"\n";
            for (int s=1; s<=2;++s)
        {
            std::cout<<"Innerererererererererer: "<<s<<"\n";
            for (int t=1; t<=2;++t)
        {
            std::cout<<"Innererererererererererer: "<<t<<"\n";
            for (int u=1; u<=2;++u)
        {
            std::cout<<"Innerererererererererererer: "<<u<<"\n";
            for (int v=1;v<=2;++v)
            {
                std::cout<<"Innererererererererererererer: "<<v<<"\n";
            }
        }
            }
            
        }
            
        }
            
            }
        }
        }
        }
        }
            }
        }
        }
    }
}

