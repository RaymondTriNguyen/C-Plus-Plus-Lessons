#include <iostream>
#include <string>
int main()
{
  //Question 1
    //d::cout<<"The color red is red-colored. \nSome apples are also red-colored.";
    //Question 2
    /*int x=2, y=x, z=x;
    std::cout<<x<<" "<<y<<" "<<z;*/
    //Question 3
   /* int daysInLeapYear=366;
    std::cout<<"There are "<<daysInLeapYear<<" days in a leap year.";*/
    //Question 4
   /*std::string euro="€";
char initial='E';
std::cout<<"The euro symbol is '"<<euro<<"' and the first initial of Europe is '"<<initial<<"'.";*/
//Using character wouldn't allow the euro to be typed.
//Question 5
/*bool on=true;
bool off=false;
std::cout<<on<<" "<<off;*/
//Question 6
/*int a=100;
int b=86;
int c=90;
int d=40;
int e=1;
std::cout<<"The first grade is "<<a<<". \n";
std::cout<<"The second grade is "<<b<<". \n";
std::cout<<"The third grade is "<<c<<". \n";
std::cout<<"The fourth grade is "<<d<<". \n";
std::cout<<"The fifth grade is "<<e<<". \n";*/
//Question 7
/*std::string country="America";
std::cout<<"I live in "<<country<<".";*/
//Question 8
/*double a=123123131312412145451451451465134.03;
float b=414.3;
std::string c="word";
std::cout<<a<<"\n"<<b<<"\n"<<c<<"\n";*/
//Question 9
/*int hours;
std::cout<<"Input a number of hours. ";
std::cin>>hours;
int minutes=hours*60;
std::cout<<"There are "<<minutes<<" minutes in "<<hours<<" hours.";*/
///Question 10
/*int grade;
std::string subject;
std::cout<<"What is your favorite subject? ";
std::cin>>subject;
std::cout<<"What grade did you get in it? ";
std::cin>>grade;
std::cout<<"Your favorite subject is "<<subject<<". \nYou got a(n) "<<grade<<" in it.";*/
//Question 11
/*double a;
double b;
std::cout<<"Enter your first number. ";
std::cin>>a;
std::cout<<"Enter your second number. ";
std::cin>>b;
double sum=a+b;
double difference=a-b;
double product=a*b;
double quotient=a/b;
std::cout<<a<<" + "<<b<<" = "<<sum<<"\n";
std::cout<<a<<" - "<<b<<" = "<<difference<<"\n";
std::cout<<a<<" * "<<b<<" = "<<product<<"\n";
std::cout<<a<<" / "<<b<<" = "<<quotient<<"\n";*/
//Question 12
/*std::string first="Hello everyone!";
std::string second="Today is my assignment day. The assignment inclues questions about";
std::string one;
std::string two;
std::string three;
std::string four;
std::cout<<"List 4 things a coding assignment would have in it. \n";
std::cin>>one;
std::cin>>two;
std::cin>>three;
std::cin>>four;
std::cout<<first<<"\n\t"<<second<<" "<<one<<", \n"<<two<<", "<<three<<", and "<<four<<".";*/
//Question 13
/*std::string one="concat";
std::string two="enation";
std::cout<<"Concatenation: \n";
std::cout<<one<<" + "<<two<<" = "<<one+two<<"\n";
std::cout<<"Append \n";
std::cout<<one<<".append("<<two<<"] = "<<one.append(two);*/
//Question 14
/*std::string string="string";
int stringLength=string.length();
std::cout<<"The length of "<<string<<" is "<<stringLength;*/
//Question 15
/*int x=50;
int y=10;
std::cout<<"The minimum is "<<std::min(x,y)<<"\n";
std::cout<<"The maximum is "<<std::max(x,y);*/
}
